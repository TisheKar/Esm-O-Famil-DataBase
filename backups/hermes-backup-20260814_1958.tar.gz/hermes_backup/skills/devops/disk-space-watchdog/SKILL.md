---
name: disk-space-watchdog
description: Use when building self-healing disk watchdogs or cleanup.
---

# Disk Space Watchdog

## Trigger
User asks for: automated disk monitoring, "keep disk under X%", "delete the least important files first when it gets full", "don't touch critical files", or any recurring self-healing cleanup job. Also relevant for generic "watch a metric and take tiered corrective action" ops tasks.

## Workflow
1. **Survey the filesystem first.** Run `df -h` to see which mount the user cares about (e.g. `/data`, `/`). Report current usage vs the requested threshold.
2. **Write a self-contained watchdog script** (Python, stdlib only) under `~/.hermes/scripts/`. It must:
   - Measure usage % via `shutil.disk_usage(path)` → `used/total*100`.
   - Have configurable `THRESHOLD` (default 70.0) and `TARGET_DIR`.
   - Define `CRITICAL_DIRECTORIES`: the agent's own state dir (`.hermes`) and every config/state file (`config.yaml`, `auth.json`, `SOUL.md`, `state.db`, `memories`, `skills`, `sessions`, `cron`, `kanban.db`). NEVER delete these.
   - Implement `is_safe_to_delete(path)` → False if path == or startswith any critical entry; allow only explicit cache subdirs (e.g. `.hermes/audio_cache`, `.hermes/image_cache`, `.hermes/cache`) to be cleaned.
   - Implement tiered generators, oldest-modified-first within each tier:
     - Tier 1: caches & temp (`/tmp/*`, `/var/tmp/*`, `__pycache__`, `*.pyc`, `*.tmp`, `*.log`, agent caches).
     - Tier 2: downloads & build artifacts (`downloads/`, `build/`, `dist/`, `.pytest_cache`, `.mypy_cache`, `node_modules/.cache`).
     - Tier 3: oldest workspace files.
   - Loop tiers only while usage >= threshold; stop as soon as it drops below (back-to-normal halt).
   - **Silent watchdog:** if initial usage < threshold, exit immediately with no output.
   - When action is taken, emit a Telegram-friendly report (before/after %, list of deleted files) to stdout — this becomes the delivered message.
3. **Test the safety logic BEFORE scheduling.** Run the module's functions: confirm `is_safe_to_delete('/data/.hermes/SOUL.md') == False` and `is_safe_to_delete('/data/.hermes/audio_cache/x') == True`, and that candidate lists are sane.
4. **Schedule as a no_agent cron job:**
   ```
   cronjob action=create name=... no_agent=true schedule="every 10m" script=<name>.py prompt="<PLAIN ASCII SUMMARY>"
   ```
   - `no_agent=true` so the script IS the job (no LLM; script stdout is delivered verbatim).
   - `prompt` is required but ignored when `no_agent=true` — keep it plain ASCII (see Pitfalls).
   - Deliver to `origin` (default) so the user gets the report only when cleanup actually fires.

## Pitfalls
- **Invisible Unicode rejection:** the cron `prompt` field silently BLOCKS text containing ZWNJ (U+200C) and similar invisible chars — common in Persian/Farsi. Write the prompt in plain English ASCII or it errors: "Blocked: prompt contains invisible unicode". The script's internal output (delivered to the user) can be any language; only the `prompt` arg must be ASCII.
- **Protect your own brain:** always whitelist `.hermes` and its state files. A watchdog that deletes the agent's config/auth/state is catastrophic and irreversible. Allow only cache subdirs inside `.hermes` to be cleaned.
- **Silent by default:** a no_agent watchdog must produce empty stdout when nothing happens, or the user gets spammed every interval.
- **Stable output:** keep watchdog output deterministic (no timestamps/random ordering) so monitor-mode hashing doesn't false-trigger. For a plain `script` (not `monitor_script`), idle silence matters most.
- **Test before fire:** verify `is_safe_to_delete` returns False for critical paths and True for cache paths before the first scheduled run — the first real fire should never be the first test.

## Support files
- `scripts/disk_cleaner.py` — ready-to-adapt template implementing the full tiered watchdog with critical-file protection and silent-watchdog behavior.
