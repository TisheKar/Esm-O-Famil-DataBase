#!/usr/bin/env python3
"""Tiered self-healing disk-space watchdog with critical-file protection.

Usage (as a no_agent cron job): python3 disk_cleaner.py
Silent when usage is below THRESHOLD; emits a report to stdout otherwise.
"""
import os
import shutil
import glob

# ---------------- Config ----------------
TARGET_DIR = "/data"
THRESHOLD = 70.0  # percent

# Agent's own state — NEVER delete. Only explicit cache subdirs below are allowed.
CRITICAL_DIRECTORIES = {
    "/data/.hermes",
    "/data/.hermes/config.yaml",
    "/data/.hermes/auth.json",
    "/data/.hermes/SOUL.md",
    "/data/.hermes/state.db",
    "/data/.hermes/memories",
    "/data/.hermes/skills",
    "/data/.hermes/sessions",
    "/data/.hermes/cron",
    "/data/.hermes/kanban.db",
}
# Safe-to-clean cache subdirs inside .hermes
SAFE_CACHE_PREFIXES = (
    "/data/.hermes/audio_cache/",
    "/data/.hermes/image_cache/",
    "/data/.hermes/cache/",
)


def get_disk_usage_percent(path=TARGET_DIR):
    stat = shutil.disk_usage(path)
    return (stat.used / stat.total) * 100


def is_safe_to_delete(path):
    abs_path = os.path.abspath(path)
    for crit in CRITICAL_DIRECTORIES:
        if abs_path == crit or abs_path.startswith(crit + "/"):
            if abs_path.startswith(SAFE_CACHE_PREFIXES):
                return True
            return False
    return True


def delete_path(path):
    try:
        if os.path.isfile(path) or os.path.islink(path):
            os.remove(path)
            return True
        if os.path.isdir(path):
            shutil.rmtree(path)
            return True
    except Exception:
        pass
    return False


def item_size(path):
    try:
        if os.path.isfile(path):
            return os.path.getsize(path)
        if os.path.isdir(path):
            return sum(
                os.path.getsize(os.path.join(d, f))
                for d, _, fs in os.walk(path)
                for f in fs
            )
    except Exception:
        return 0
    return 0


def clean_tier(generator, tier_name, cleaned_log):
    if get_disk_usage_percent() < THRESHOLD:
        return get_disk_usage_percent()
    for item in generator():
        if get_disk_usage_percent() < THRESHOLD:
            break
        if is_safe_to_delete(item) and delete_path(item):
            cleaned_log.append(f"[{tier_name}] {item} (~{item_size(item)//1024} KB)")
    return get_disk_usage_percent()


def get_tier1_files():
    patterns = [
        "/tmp/*", "/var/tmp/*",
        "/data/.hermes/audio_cache/*", "/data/.hermes/image_cache/*",
        "/data/.hermes/cache/*",
        "/data/workspace/**/__pycache__", "/data/workspace/**/*.pyc",
        "/data/workspace/**/*.tmp", "/data/workspace/**/*.log",
    ]
    files = [f for p in patterns for f in glob.glob(p, recursive=True)]
    return sorted(files, key=lambda p: os.path.getmtime(p) if os.path.exists(p) else 0)


def get_tier2_files():
    patterns = [
        "/data/workspace/downloads/*", "/data/workspace/build/*",
        "/data/workspace/dist/*", "/data/workspace/.pytest_cache",
        "/data/workspace/.mypy_cache", "/data/workspace/node_modules/.cache",
    ]
    files = [f for p in patterns for f in glob.glob(p, recursive=True)]
    return sorted(files, key=lambda p: os.path.getmtime(p) if os.path.exists(p) else 0)


def get_tier3_files():
    files = []
    ws = "/data/workspace"
    if os.path.exists(ws):
        for root, dirs, filenames in os.walk(ws):
            if "/.git" in root or "/.hermes" in root:
                continue
            for f in filenames:
                files.append(os.path.join(root, f))
    return sorted(files, key=lambda p: os.path.getmtime(p) if os.path.exists(p) else 0)


def main():
    initial = get_disk_usage_percent()
    if initial < THRESHOLD:
        return  # silent watchdog

    cleaned = []
    usage = clean_tier(get_tier1_files, "T1:caches/temp", cleaned)
    if usage >= THRESHOLD:
        usage = clean_tier(get_tier2_files, "T2:build/downloads", cleaned)
    if usage >= THRESHOLD:
        usage = clean_tier(get_tier3_files, "T3:old workspace", cleaned)

    final = get_disk_usage_percent()
    lines = [
        f"DISK WATCHDOG REPORT",
        f"usage before: {initial:.1f}%  after: {final:.1f}%",
        f"status: {'OK below threshold' if final < THRESHOLD else 'STILL ABOVE THRESHOLD - manual check needed'}",
        f"deleted items: {len(cleaned)}",
    ]
    for item in cleaned[:20]:
        lines.append(f"- {item}")
    if len(cleaned) > 20:
        lines.append(f"- ... and {len(cleaned) - 20} more")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
